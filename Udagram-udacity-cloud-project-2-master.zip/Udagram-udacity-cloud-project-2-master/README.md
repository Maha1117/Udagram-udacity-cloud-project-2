# Udacity Cloud developer Project 2
## Udagram Monolith - FullStack App on AWS

This project is part of udacity cloud developer nanodegree - [Repository link](https://github.com/ousat/Udagram-udacity-cloud-project-2)


[AWS site link](http://projectudagram-env.eba-anw4bmaz.us-east-1.elasticbeanstalk.com/) 

[Filtered image example](http://projectudagram-env.eba-anw4bmaz.us-east-1.elasticbeanstalk.com/filteredimage?image_url=https://www.w3schools.com/w3css/img_lights.jpg)


Screenshot of deployment on AWS Elastic beanstalk:


![aws screenshot](https://raw.githubusercontent.com/ousat/Udagram-udacity-cloud-project-2/master/screenshots/deployed_on_eb.png)



